<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpressdata' );

/** MySQL database username */
define( 'DB_USER', 'jsilance' );

/** MySQL database password */
define( 'DB_PASSWORD', 'jsilance' );

/** MySQL hostname */
define( 'DB_HOST', 'my-mysql' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define('WP_ALLOW_REPAIR', true);

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0MS}y<U})R>$?HL`m/~1PgmE,*K_5*wTWt:nQ~JqxCh62D8MY!b/J:>&N_,>k4Zk' );
define( 'SECURE_AUTH_KEY',  'jzhJ8&8vQZjPP;y/AR8DAyfQot.Avkvx@dk(q^xe]0K$_&&-&|E;qm#A7I>Kv>Kb' );
define( 'LOGGED_IN_KEY',    '(^0p;jr_2Rpo4PoI5&o6}obYE/eq6$MO0:kLGZ1<D}by%2teu}T#]DH/]R+I&AYc' );
define( 'NONCE_KEY',        'Ga+}P4G/`,),~(s0f/v7HKs?x`{:9{}3`rA[WZ*0tw;cNY 0/%:%wP:8bM;r::`0' );
define( 'AUTH_SALT',        'SOr/0MtVLaWbTo<(cjgE:]vk6?{z.H_KWgwG=j)6w4o/6{!})dAIZNuSf7:;^k[S' );
define( 'SECURE_AUTH_SALT', 'ly&EIh}95v6#|/Rj8?y^<eO*]I= 5Y!M||Sgf#nec0h<%-[*0D7X^OiKSWz9vV7y' );
define( 'LOGGED_IN_SALT',   't(mM&x3VT6!mh0$MRoAUPK|ZpKHF&r3]oJZ-)MZ[c9ySZ#ymvkIGfQ}0l;+yBZom' );
define( 'NONCE_SALT',       'M(NEMr@L7g0y0ewVY-SU3pj$JJ[xNh5NSqEv9;J@6IrJYeQL;;[fH|B6}#C$(%5J' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

define( 'WP_DEBUG_LOG', '/tmp/wp-errors.log' );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
